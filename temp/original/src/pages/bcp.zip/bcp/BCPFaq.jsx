const faqs = [
  {
    q: "Why is a Business Impact Analysis (BIA) necessary?",
    a: "A BIA quantifies the financial, operational, and reputational impacts of potential risks. It helps prioritize critical functions and determines the Maximum Tolerable Period of Disruption (MTPD) for your operations.",
  },
  {
    q: "How do you identify potential risks to our organization?",
    a: "We conduct a comprehensive Risk Assessment (RA) to categorize internal and external threats, such as cyberattacks, natural disasters, supply chain failures, and power outages.",
  },
  {
    q: "Is our approach aligned with international standards?",
    a: "Yes, our BCP/DR frameworks are designed in strict alignment with ISO 22301 global best practices, ensuring a standardized and rigorous Business Continuity Management System (BCMS).",
  },
  {
    q: "How often should BCP and DR plans be tested?",
    a: "Plans should be tested regularly through tabletop exercises, simulations, and drills. Regular testing validates the effectiveness of recovery strategies and identifies gaps before an actual crisis occurs.",
  },
  {
    q: "What documentation is provided at the end of the project?",
    a: "You receive a complete BCMS toolkit, including a Business Continuity Management Policy, BIA reports, Recovery Strategies, Training Plans, and Maintenance Review Plans.",
  },
];

const BCPFaq = () => {
  return (
    <section className="bg-surfaceLight dark:bg-surfaceDark">
      <div className="container py-16 max-w-4xl">
        <h2 className="font-heading text-3xl font-bold text-brandDark dark:text-white">
          Frequently Asked Questions
        </h2>

        <div className="mt-10 space-y-6">
          {faqs.map((item, i) => (
            <div
              key={i}
              className="p-6 rounded-xl border border-borderLight dark:border-borderDark"
            >
              <h3 className="font-semibold text-brandPrimary">{item.q}</h3>
              <p className="mt-3 text-gray-700 dark:text-gray-300">
                {item.a}
              </p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default BCPFaq;
