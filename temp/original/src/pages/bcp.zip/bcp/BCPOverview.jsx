const BCPOverview = () => {
  return (
    <section className="bg-surfaceLight dark:bg-surfaceDark border-y border-borderLight dark:border-borderDark">
      <div className="container py-16 max-w-4xl">
        <h2 className="font-heading text-3xl font-bold text-brandDark dark:text-white">
          Resilient Business Continuity & Disaster Recovery
        </h2>

        <p className="mt-6 text-gray-700 dark:text-gray-300 leading-relaxed">
          RiskMan provides tailored BCP and DR frameworks to safeguard
          organizations against unforeseen disruptions. Our strategic foresight
          and meticulous analysis ensure operational stability, mitigating risks
          through proactive strategy formulation to fortify your organization’s
          longevity in today’s dynamic landscape.
        </p>
      </div>
    </section>
  );
};

export default BCPOverview;
