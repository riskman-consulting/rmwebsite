const BCPCallToAction = () => {
  return (
    <section className="bg-brandPrimary">
      <div className="container py-16 text-center max-w-3xl">
        <h2 className="font-heading text-3xl font-bold text-white">
          Protect Your Organization’s Future
        </h2>

        <p className="mt-5 text-white/90 text-lg">
          Contact us today to build a culture of resilience within your organization
        </p>

        <button className="mt-8 px-8 py-3 rounded-lg bg-brandAccent text-brandDark font-bold hover:bg-brandGold transition">
          Book a Consultation
        </button>
      </div>
    </section>
  );
};

export default BCPCallToAction;
