const BCPBenefits = () => {
  return (
    <section className="bg-bgLight dark:bg-bgDark">
      <div className="container py-16">
        <div className="max-w-5xl">
          <h2 className="font-heading text-3xl font-bold text-brandDark dark:text-white">
            Business Continuity & Disaster Recovery Focus Areas
          </h2>

          <div className="grid md:grid-cols-2 gap-8 mt-10">
            <div className="p-6 rounded-xl border border-borderLight dark:border-borderDark bg-surfaceLight dark:bg-surfaceDark">
              <h3 className="font-semibold text-lg text-brandPrimary">
                Business Impact Analysis (BIA)
              </h3>
              <p className="mt-3 text-gray-700 dark:text-gray-300">
                A BIA quantifies the financial, operational, and reputational
                impacts of potential risks. It helps prioritize critical
                functions and determines the Maximum Tolerable Period of
                Disruption (MTPD) for your operations.
              </p>
            </div>

            <div className="p-6 rounded-xl border border-borderLight dark:border-borderDark bg-surfaceLight dark:bg-surfaceDark">
              <h3 className="font-semibold text-lg text-brandPrimary">
                Risk Assessment
              </h3>
              <p className="mt-3 text-gray-700 dark:text-gray-300">
                We conduct a comprehensive Risk Assessment (RA) to categorize
                internal and external threats, such as cyberattacks, natural
                disasters, supply chain failures, and power outages.
              </p>
            </div>

            <div className="p-6 rounded-xl border border-borderLight dark:border-borderDark bg-surfaceLight dark:bg-surfaceDark">
              <h3 className="font-semibold text-lg text-brandPrimary">
                ISO Alignment
              </h3>
              <p className="mt-3 text-gray-700 dark:text-gray-300">
                Our BCP/DR frameworks are designed in strict alignment with
                ISO 22301 global best practices, ensuring a standardized and
                rigorous Business Continuity Management System (BCMS).
              </p>
            </div>

            <div className="p-6 rounded-xl border border-borderLight dark:border-borderDark bg-surfaceLight dark:bg-surfaceDark">
              <h3 className="font-semibold text-lg text-brandPrimary">
                Testing & Documentation
              </h3>
              <p className="mt-3 text-gray-700 dark:text-gray-300">
                Plans are tested through tabletop exercises, simulations, and
                drills, with complete BCMS documentation delivered including
                policies, BIA reports, recovery strategies, and maintenance plans.
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default BCPBenefits;
