import BCPHero from "./BCPHero";
import BCPOverview from "./BCPOverview";
import BCPBenefits from "./BCPBenefits";
import BCPCallToAction from "./BCPCallToAction";
import BCPFaq from "./BCPFaq";

const BCPPage = () => {
  return (
    <>
      <BCPHero />
      <BCPOverview />
      <BCPBenefits />
      <BCPCallToAction />
      <BCPFaq />
    </>
  );
};

export default BCPPage;
